#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: Gh0st Zer0
# @Date:   2020-12-24 21:33:30
# @Last Modified by:   Gh0st Zer0
# @Last Modified time: 2020-12-24 21:34:08

import sys
import os
import re
import string
import binascii
import time
from collections import OrderedDict
from os.path import dirname, abspath
sys.path.append(dirname(abspath(__file__)))
import numpy as np
from copy import deepcopy as dc
import networkx as nx
from sklearn.metrics import auc, roc_curve, precision_score, recall_score, f1_score

from idautils import *
import idaapi
from idaapi import *
from idc import *

from opcodes import *
from features_get import *
from results_show_ida import *

from gen_pyvex_ir import *
from ida_utils import *

#to do
#对x86寄存器归一化处理，因为相同的寄存器，由于长度的不同导致名字的变化。
# 对函数返回值的处理
# 这个数据流图是包含顺序的，每条边应该编个序号，即搜索出来的路径，严格的说必须从小到大
x86_regname_unify = {
    "al": "eax", "ah": "eax", "ax": "eax", "eax": "eax", "rax": "eax",
    "bl": "ebx", "bh": "ebx", "bx": "ebx", "ebx": "ebx", "rbx": "ebx",
    "cl": "ecx", "ch": "ecx", "cx": "ecx", "ecx": "ecx", "rcx": "ecx",
    "dl": "edx", "dh": "edx", "dx": "edx", "edx": "edx", "rdx": "edx",
    "si": "esi", "sil": "esi", "esi": "esi",
    "di": "edi", "dil": "edi", "edi": "edi",
    "ip": "eip", "eip": "eip",
    "bp": "ebp", "bpl": "ebp", "ebp": "ebp",
    "sp": "esp", "spl": "esp", "esp": "esp"
}


ret_reg_dict = OrderedDict([
    ('x86', 'eax'),
    ('x64', 'rax'),
    ('mipsbe', 'v0'),   #twe return reg, UC_MIPS_REG_V0, UC_MIPS_REG_V1
    ('mipsle', 'v0'),
    ('mips64be', 'v0'),
    ('mips64le', 'v0'),
    ('armbe', 'r0'),
    ('armle', 'r0'),
    ('arm64be', 'x0'),
    ('arm64le', 'x0'),
    ('ppcbe', 'r3'),
    ('ppcle', 'r3'),
    ('ppc64be', 'r3'),
    ('ppc64le', 'r3')
    ])
arg_reg_dict = OrderedDict([
    ('x86', []),
    ('x64', []),
    ('mipsbe', ['a0', 'a1', 'a2', 'a3']),
    ('mipsle', ['a0', 'a1', 'a2', 'a3']),
    ('mips64be', ['a0', 'a1', 'a2', 'a3']),
    ('mips64le', ['a0', 'a1', 'a2', 'a3']),
    ('armbe', ['R0', 'R1', 'R2', 'R3']),
    ('armle', ['R0', 'R1', 'R2', 'R3']),
    ('arm64be', ['X0', 'X1', 'X2', 'X3']),
    ('arm64le', ['X0', 'X1', 'X2', 'X3']),
    ('ppcbe', ['gpr3', 'gpr4', 'gpr5', 'gpr6', 'gpr7', 'gpr8', 'gpr9', 'gpr10']),
    ('ppcle', ['gpr3', 'gpr4', 'gpr5', 'gpr6', 'gpr7', 'gpr8', 'gpr9', 'gpr10']),
    ('ppc64be', ['gpr3', 'gpr4', 'gpr5', 'gpr6', 'gpr7', 'gpr8', 'gpr9', 'gpr10']),
    ('ppc64le', ['gpr3', 'gpr4', 'gpr5', 'gpr6', 'gpr7', 'gpr8', 'gpr9', 'gpr10'])
    ])

def get_reg_name(ea, arch):
    str = generate_disasm_line(ea,0)
    #print(str)
    src_reg = None
    dst_reg = None
    stack_reg = ['$sp', 'SP', 'r1', '$fp', '$gp']
    if 'mips' in arch or 'ppc' in arch:
        src_reg = re.findall(r"\((.+?)\)", str)
        dst_reg = print_operand(ea, 0)
        if src_reg[0] in stack_reg or dst_reg in stack_reg:
            return None, None
        return dst_reg, src_reg[0]
    elif 'arm'in arch:
        reg = re.findall(r"\[(.+?)\]", str)
        dst_reg = print_operand(ea, 0)
        if '#' in reg[0] or ',' in reg[0]:
            src_reg = reg[0].split(',')[0]
            if src_reg in stack_reg or dst_reg in stack_reg:
                return None, None
            return dst_reg, src_reg
        else:
            src_reg = reg[0]
            if src_reg in stack_reg or dst_reg in stack_reg:
                return None, None
            return dst_reg, src_reg
    else:
        return None, None

def analyze_flow(load_flow, store_flow):

    flow_nums = 0       # how many data flow
    load_reg_dict = {}
    store_reg_dict = {}
    sink_set = set()
    for val in load_flow:
        src_reg, dst_reg = val.split('->')
        #if src_reg == dst_reg:
            #continue
        try:
           load_reg_dict[dst_reg].append(src_reg)
        except:
            load_reg_dict[dst_reg]=[]
            load_reg_dict[dst_reg].append(src_reg)

    for val in store_flow:
        src_reg, dst_reg = val.split('->')
        try:
           store_reg_dict[dst_reg].append(src_reg)
        except:
            store_reg_dict[dst_reg]=[]
            store_reg_dict[dst_reg].append(src_reg)
    #print(load_reg_dict, store_reg_dict)
    flag = False
    for key, val in load_reg_dict.items():
        flag = False
        for succ_key, succ_val in store_reg_dict.items():
            if key in succ_val and succ_key not in val:
                flag = True
                sink_set.add(succ_key)
        if flag == False:
            sink_set.add(key)
            sink_set.update(val)
    flow_nums = len(sink_set)
    #print(sink_set)
    return flow_nums


def data_flow(blocks, path):
    flag = 0
    loads, stores, branch, arithmetic = get_insts_set()
    arch = idaapi.get_inf_structure().procName.lower()
    
    store_flows = []
    load_flows = []
    for ix in path:
        start_ea = blocks[ix][0]
        end_ea = blocks[ix][1]

        while start_ea < end_ea:
            opcode = print_insn_mnem(start_ea)
            optype0 = get_operand_type(start_ea, 0)
            optype1 = get_operand_type(start_ea, 1)
            optype2 = get_operand_type(start_ea, 2)
            if opcode in loads and optype1 == 0x4:
                    
                dst_reg, src_reg = get_reg_name(start_ea, arch)

                if dst_reg != None and src_reg != None:
                    rela = src_reg + '->' + dst_reg     # indictate data flow from memory to register
                    load_flows.append(rela)
            elif opcode in stores and optype1 == 0x4:
                    
                src_reg, dst_reg = get_reg_name(start_ea, arch)
                if dst_reg != None and src_reg != None:
                    rela = src_reg + '->' + dst_reg     # indictate data flow from register to memory
                    store_flows.append(rela)
            '''
            elif opcode in arithmetic:
                src_reg, dst_reg = get_reg_name(start_ea, arch)
                rela = src_reg + '->' + dst_reg
                flows.append(rela)
            '''
            start_ea = next_head(start_ea)

        #先不管算术运算以及函数的调用
        #对flow进行分析
    #print(load_flows, store_flows)
    if analyze_flow(load_flows, store_flows) == 1:      # we think that only one data flow in the copy flow.
        flag = 1

    return flag

def is_inPath(node, paths):
    for path in paths:
        if node in path:
            return True
    return False
def find_father(succs, node, path):

    for i in range(len(succs)):
        if (i not in path) and node in succs[i]:
            return i

    return -1

def find_start_block(succs, path, prev = [], block_id = 0):

    start = None
    #print("loop path:", path)
    #默认函数入口的block id 为0
    func_start_succs = succs[block_id]
    #print(func_start_succs)
    #print("prev:", prev)
    if block_id in prev:
        return
    
    
    for node in func_start_succs:
        if node in path:
            return node
    prev.append(block_id)
    for node in func_start_succs:
        start = find_start_block(succs, path, prev, node)
        if start != None:
            return start

def get_order_path(loops, blocks):

    loop_start = []


    succs = get_block_succs(blocks)
    #print(succs)
    for path in loops:
        start_node_id = find_start_block(succs, path, [])
        loop_start.append(start_node_id)
    
    new_loops = []
    i = 0
    for st in loop_start:
        if st not in loops[i]:
            continue
        st_index = loops[i].index(st)
        temp_path = loops[i][st_index:] + loops[i][0:st_index]
        new_loops.append(temp_path)
        i += 1
        #smallest_addr = sorted(blocks_start)[0]
        #loop_start_list.append(smallest_addr)

    return new_loops


def filter_vex_str(vex_str):
    #t7 = if (t58) ILGop_Ident32(LDbe(t23)) else t27
    # if (t60) STbe(t35) = t7
    if "ST" in vex_str:
        pattern = r'ST.*?\((.*?)\)'
        res = re.findall(pattern, vex_str)
        ret_str = res[0]
        return ret_str
    if "LD" in vex_str:
        pattern = r'LD.*?\((.*?)\)'
        res = re.findall(pattern, vex_str)
        ret_str = res[0]
        return ret_str
    ret_str = None
    if '(' in vex_str:
        pattern = r'\((.*?)\)'
        res = re.findall(pattern, vex_str)
        if len(res) != 1:
            print("[-] Found more than one '()' %s" % vex_str)
            return ret_str
        else:
            res = res[0]
            if ',' in res:
                ret_str_0 = res.split(',')[0].strip(' ')
                ret_str_1 = res.split(',')[1].strip(' ')
                if "t" in ret_str_1:
                    ret_str = (ret_str_0, ret_str_1)
                else:
                    ret_str = ret_str_0
            else:
                ret_str = res
            return ret_str
    else:
        ret_str = vex_str
        return ret_str

def split_irsb_dst_src(irsb):
    data_pairs = []
    LD_node  = []
    ST_node = []
    ADD_node = []
    LD_first_flag = False
    CMP_flag = False
    LD_ST_order = []

    for _, stmt in enumerate(irsb.statements):
        
        #print(type(stmt))
        if isinstance(stmt, pyvex.stmt.Put):
            stmt_str = stmt.__str__(reg_name=irsb.arch.translate_register_name(stmt.offset, stmt.data.result_size(irsb.tyenv) // 8))
        elif isinstance(stmt, pyvex.stmt.WrTmp) and isinstance(stmt.data, pyvex.expr.Get):
            stmt_str = stmt.__str__(reg_name=irsb.arch.translate_register_name(stmt.data.offset, stmt.data.result_size(irsb.tyenv) // 8))
        elif isinstance(stmt, pyvex.stmt.Exit):
            stmt_str = stmt.pp_str(reg_name=irsb.arch.translate_register_name(stmt.offsIP, irsb.arch.bits // 8))
        else:
            stmt_str = stmt.__str__()
        #print(stmt_str)
        if "IMark" in stmt_str:
            CMP_flag = False
        if 'Cmp' in stmt_str:
            CMP_flag = True
        if CMP_flag:
            continue
        if "cc_" in stmt_str or "pc" in stmt_str or "ip" in stmt_str or 'ra' in stmt_str:
            continue
        if '=' in stmt_str:
            #print(stmt_str)
            dst_str, src_str = [x.strip(' ') for x in stmt_str.split('=')]
            #print(dst_str, src_str)
            arch  = get_arch()
            
            dst = filter_vex_str(dst_str)
            if dst != None:
                src = filter_vex_str(src_str)
                if arch == 'x86':
                    try:
                        dst = x86_regname_unify[dst]
                    except:
                        pass
                    try:
                        src = x86_regname_unify[src]
                    except:
                        pass
                if "0x" in src:
                    continue
                if "(" not in stmt_str:
                    data_pairs.append((src, dst))
                else:
                    data_pairs.append((dst, src))
            if "ST" in stmt_str:
                ST_node.append(dst)
                LD_ST_order.append(dst)
            if "LD" in stmt_str:
                if len(ST_node) == 0:
                    LD_first_flag = True
                LD_node.append(src)
                LD_ST_order.append(src)
            if "Add" in stmt_str or "Sh" in stmt_str:
                ADD_node.append(dst)
        else:
            continue
    return data_pairs, ST_node, LD_node, ADD_node, LD_first_flag, LD_ST_order



def is_copy_func_with_vex(func, blocks, debug = False):
    flag = 0
    loops = []
    res = []
    succs = get_block_succs(blocks)
    #debug = True
    #print(succs)
    #arch = idaapi.get_inf_structure().procName.lower()
    # load mode and store mode in vex

    #loads, stores, branch, arithmetic= get_insts_set()
    path_thresh = 8    #循环上基本块数阈值
    call_thresh = 2     #函数调用数阈值
    inst_thresh = 20    #循环路径上指令数阈值
    loose = True
    if loose:
        store_thresh =  8  #循环块包含的存储指令阈值
        load_thresh = 8    #循环块包含的加载指令阈值
    else:
        store_thresh = 3   #循环块包含的存储指令阈值
        load_thresh = 3     #循环块包含的加载指令阈值

    start_block_ea = 0

    G = nx.DiGraph()
    for i in range(len(succs)):
        for id in succs[i]:
            G.add_edge(i, id)
    try:
        res = list(nx.simple_cycles(G)) # find the loop paths
        #res = list(nx.cycle_basis(G, 0))
    except:
        pass
    if res == []:   # no loop
        return 0, 0

    for path in res:    # get all loop paths
        loops.append(path)
    
    if debug: 
        print(len(loops))
    #print(get_func_name(func.start_ea))
    if len(loops) > 50:     # too many loop paths
        return 0, 0
    
    if loops != []:
        if debug:
            print("Orginal loops:", loops)
        loops = get_order_path(loops, blocks)
        if debug:
            print("Ordered loops:", loops)
        for path in loops:      # does the path do the copy (from one address to another)
            #print(path)
            #print(len(path))
            add_flag = 0
            ADD_node_loop = []
            
            inst_nums = 0
            ix = path[0]
            start_ea = blocks[ix][0]
            if debug:
                print("block start 0x%x" % start_ea)
            start_block_ea = start_ea
            for ix in path:
                start_ea = blocks[ix][0]
                if debug:
                    print("block start 0x%x" % start_ea)
                end_ea = blocks[ix][1]
                addr_list = list(Heads(start_ea, end_ea))
                inst_nums += len(addr_list)

            if len(path) > path_thresh and inst_nums > inst_thresh:
                continue

            ix = path[0]
            start_ea = blocks[ix][0]
            end_ea = blocks[ix][1]
            call_times = 0
            loop_irsb, call_times = get_block_vex_whole(start_ea, end_ea, True)
            for i in range(1, len(path)):
                ix = path[i]
                start_ea = blocks[ix][0]
                end_ea = blocks[ix][1]

                temp_isrb, temp_times = get_block_vex_whole(start_ea, end_ea, True)
                loop_irsb.extend(temp_isrb)
                call_times += temp_times
            if debug:
                print(loop_irsb)
                print("call:", call_times)
            data_pairs, ST_node, LD_node, ADD_node, LD_first_flag, LD_ST_order = split_irsb_dst_src(loop_irsb)
            if debug:
                print("Loop:", res)
                print(data_pairs, ST_node, LD_node, ADD_node)
            if call_times > call_thresh:
                continue
            if call_times != 0:
                arch = get_arch()
                args_reg_list = arg_reg_dict[arch]
                ret_reg = ret_reg_dict[arch]
                for arg_reg in args_reg_list:
                    data_pairs.append((ret_reg, arg_reg))
            if LD_first_flag == False:
                continue
            if ST_node == [] or LD_node == [] or ADD_node == []:
                continue        #不满足条件
            if len(ST_node) > store_thresh or len(LD_node) > load_thresh:
                continue
            data_flow = nx.DiGraph()
            for (dst, src) in data_pairs:
                if isinstance(src, tuple):
                    data_flow.add_edge(src[0], dst)
                    data_flow.add_edge(src[1], dst)
                else:

                    data_flow.add_edge(src, dst)
            try:
                res = list(nx.simple_cycles(data_flow)) # find the loop paths
                #res = list(nx.cycle_basis(G, 0))
            except:
                continue
            #
            
            #if res == []:   # no loop
            #    continue
            for path in res:
                for nd in path:
                    if nd in ADD_node:
                        ADD_node_loop.append(nd)
            if debug:
                print("Add loop:", ADD_node_loop)
            for start in LD_node:
                for end in ST_node:
                    if LD_ST_order.index(start) >= LD_ST_order.index(end):
                        continue
                    start_prev = set(data_flow.predecessors(start))
                    
                    end_prev = set(data_flow.predecessors(end))
                    if debug:
                        print("start: %s prev: %s" % (start, start_prev))
                        print("end: %s prev: %s" % (end, end_prev))
                    if start_prev & end_prev != set() and (len(start_prev) == 1 or len(end_prev) == 1):
                        continue
                    ld_st_path_ger = nx.all_simple_paths(data_flow, start, end)
                    st_ld_path_ger = nx.all_simple_paths(data_flow, end, start)
                    st_ld_path = list(st_ld_path_ger)
                    ld_st_path = list(ld_st_path_ger)
                    if ld_st_path != [] and st_ld_path == []:
                        #
                        if debug:
                            print("Load: %s, Store: %s" % (start, end), ld_st_path)

                        if ADD_node_loop == []:
                            for nd in ADD_node:
                                if nd in ld_st_path[0]:
                                    flag = 1
                                    return 1, start_block_ea

                        for nd in ADD_node_loop:
                            add_st_path_ger = nx.all_simple_paths(data_flow, nd, end)
                            
                            add_st_path = list(add_st_path_ger)
                            if debug:
                                print("Add node: %s to store: %s, path: " % (nd, end), add_st_path)
                            #print(add_st_path == [])
                            if add_st_path != [] or nd == end:
                                flag = 1
                                return 1, start_block_ea
                        
    return flag, start_block_ea

def is_copy_func(func, blocks):
    loops = []
    res = []
    succs = get_block_succs(blocks)
    #print(succs)
    arch = idaapi.get_inf_structure().procName.lower()
    loads, stores, branch, arithmetic= get_insts_set()
    G = nx.DiGraph()
    for i in range(len(succs)):
        for id in succs[i]:
            G.add_edge(i, id)
    try:

        #print("[+] finding loops.............")
        #print(G.nodes)
        #print(len(G.edges))
        res = list(nx.simple_cycles(G)) # find the loop paths
        #print("[+] ok..............")
        #res = list(nx.cycle_basis(G, 0))
    except:
        pass
    
    if res == []:   # no loop
        return 0
    for path in res:    # get all loop paths
        loops.append(path)
    load_flag = False
    store_flag = False
    arith_flag = False
    #print(len(loops))
    #print(get_func_name(func.start_ea))
    if len(loops) > 50:     # too many loop paths
        return 0
    if loops != []:
        for path in loops:      # does the path do the copy (from one address to another)
            load_flag = False
            store_flag = False
            arith_flag = False
            #print(path)
            #print(len(path))
            if len(path) > 5:
                continue
            for ix in path:
                start_ea = blocks[ix][0]
                end_ea = blocks[ix][1]
                #print("0x%x--0x%x" % (start_ea, end_ea))
                while start_ea < end_ea:
                    opcode = print_insn_mnem(start_ea)
                    optype0 = get_operand_type(start_ea, 0)
                    optype1 = get_operand_type(start_ea, 1)
                    optype2 = get_operand_type(start_ea, 2)

                    if opcode in loads:         # load byte from memory 
                        if optype0 == 0x1 and optype1 == 0x4 :  #reg and reg+index memory
                            src_reg, dst_reg = get_reg_name(start_ea, arch)
                            
                            if dst_reg != None and src_reg != None and (dst_reg != src_reg):
                                #print(src_reg + '-' + dst_reg)
                                load_flag = True
                            else:
                                start_ea = next_head(start_ea)
                                continue
                            if 'ppc' in arch and (opcode in ppc_load) and 'u' in opcode:       # u: update
                                arith_flag = True
                            if 'arm' in arch and (opcode in arm_load):
                                if 'B' in opcode:
                                    arith_flag = True
                                elif '#' not in print_operand(start_ea,1).split(']')[0]:
                                     arith_flag = True
                                    
                    elif opcode in stores:
                        #print("in stores")
                        #str = generate_disasm_line(start_ea,0)
                        #print(str)
                        #print(optype0,optype1)
                        if optype0 == 0x1 and optype1 == 0x4 :  #reg and reg+index memory
                            src_reg, dst_reg = get_reg_name(start_ea, arch)

                            if dst_reg != None and src_reg != None and (dst_reg != src_reg):
                                #print(src_reg + '-' + dst_reg)
                                store_flag = True
                            else:
                                start_ea = next_head(start_ea)
                                continue
                            if 'ppc' in arch and (opcode in ppc_store) and 'u' in opcode:
                                arith_flag = True
                    elif opcode in arithmetic:
                        if optype1 == 0x5 or optype2 == 0x5:
                            arith_flag = True
                    start_ea = next_head(start_ea)
            #print(load_flag, store_flag, arith_flag)
            if load_flag and store_flag and arith_flag:
                flow_flag = data_flow(blocks, path)
                #print("flow flag: %d." % flow_flag)
                if flow_flag:
                    return 1

    return 0


def find_copy_funcs():
    binary_name = get_root_filename()
    global loops
    thresh = 50     # function is too large.( too many blocks)
    print("binary name: %s" % binary_name)
    func_items = {}
    id = 0
    #segm = idaapi.get_segm_by_name(".text")
    for funcea in Functions():
        line = []   # present the results
        loops = []
        func = idaapi.get_func(funcea) # get function object
        funcname = get_func_name(funcea)
        #print(funcname)
    
        #if funcname.startswith("_"):
        #    continue
        line.append(funcea)
        line.append(funcname)
        blocks = [(v.start_ea, v.end_ea) for v in idaapi.FlowChart(func)]
        if len(blocks) < 3 or len(blocks) > thresh:
            continue
        #flag = is_copy_func(func, blocks)  # get function features and successor and so on.
        flag, start_block_ea = is_copy_func_with_vex(func, blocks)
        line.append(start_block_ea)
        line.append(flag)
        line.append(1)
        func_items[id] = line
        id += 1
        #break

    return func_items

def get_single_func():
    ea = get_screen_ea()
    func = idaapi.get_func(ea) 
    funcname = get_func_name(ea)
    print("[+] is '%s' a copy function?" % funcname)
    blocks = [(v.start_ea, v.end_ea) for v in idaapi.FlowChart(func)]
    new_blocks = []
    for bb in blocks:
        if is_inBlock(bb[0], func.start_ea, func.end_ea) and is_inBlock(bb[1], func.start_ea, func.end_ea + 1):
            new_blocks.append(bb)
    blocks = new_blocks
    #flag = is_copy_func(func, blocks)
    flag, start_block_ea = is_copy_func_with_vex(func, blocks)
    if flag == 0:
        print("[-] False (0).")
    else:
        print("[+] True (1).")


def get_all_funcs(mode = False):
    start_stime = time.time()
    if mode == False:
        print("[+] Classifying function info is ok...................")
        print("[+] Finding all copy functions...............")
    func_items = find_copy_funcs()
    if mode == False:
        print("[+] Total: %d functions." % len(func_items) )


    
    #TRUE_PATH = "G:\\Projects\\findcopyfuncs\\test\\stunnel-mips-labels"
    #TRUE_PATH = "C:\\Users\\surface\\OneDrive - sjtu.edu.cn\\MyWork\\CopyFuncs\\test\\stunnel-mips-labels"
    c_lib_cpy = [
    "memcpy", "memmove", "strcpy", "strncpy", "strcat", "strncat", "strxfrm",
    "wcscat", "wcscpy", "wcsxfrm", "wcsncpy", "wmemmove", "wcsncat", "wmemcpy",
    "wcsnrtombs",
    "my_copy", "yystpcpy", "yy_flex_strncpy", "zmemcpy", "stpcpy", "unistrcpy",
    "BUF_strlcpy", "tr_strlcpy", "g_strlcpy", "wxStrncpy", "wxStrcpy", "wxStrcat",
    "w_copy", "strlcpy", "util_memcpy", "resolv_domain_to_hostname", "MD5_memcpy",
    "alpha_strcpy_fn", "StrnCpy_fn", "strncpy_w", "sstrncpy", "alps_lib_toupper"
    ]
    #print(c_lib_cpy)
    y_truth = []
    y_pre = []
    for key, value in func_items.items():
        func_name = value[1].strip("_")
        flag = value[3]
        try:
            if func_name.lower() in c_lib_cpy:
                y_truth.append(1)
            else:
                y_truth.append(0)
            y_pre.append(flag)
        except:
            continue
    y_truth = np.array(y_truth)
    y_pre = np.array(y_pre)
    precision = precision_score(y_truth, y_pre, average='binary')
    recall = recall_score(y_truth, y_pre, average='binary')
    f1 = f1_score(y_truth, y_pre, average='binary')
    end_stime = time.time()
    if mode:
        binary_name = get_root_filename()
        res = open(binary_name + '_CPFinder.txt', 'w')
        print("[+] Precision: %f, recall: %f, f1: %f." %(precision, recall, f1), file = res)
        print("Time: %f" % (end_stime - start_stime), file = res)
        res.close()
    else:
        print("[+] Precision: %f, recall: %f, f1: %f." %(precision, recall, f1))
        print("Time: %f" % (end_stime - start_stime))

        c= ResultChooser("Copy function", func_items)
        c.Show()
    
    

def main():
    batch = True
    batch = False
    if batch:
        segstart = get_first_seg()
        segend = get_segm_end(segstart)
        while True:
            plan_and_wait(segstart, segend)
            segstart = get_next_seg(segstart)
            segend = get_segm_end(segstart)
            if segend == BADADDR:
                break
        analysis_flags = get_inf_attr(idc.INF_AF)  # 得到analysis_flags  INF_AF
        analysis_flags &= ~AF_IMMOFF  # AF_IMMOFF ：将32位的指令操作转换为偏移量
        # turn off "automatically make offset" heuristic
        idc.set_inf_attr(INF_AF, analysis_flags)  # 设置analysis_flags
        mod = "all"
    else:
        mod = ask_str("single", 0, "Please type 'single' or 'all'")
   
    if mod == "all":
        get_all_funcs(batch)
    else:
        get_single_func()
    if batch:
        ida_pro.qexit(0)
    
    
if __name__ == "__main__":
    main()
        




